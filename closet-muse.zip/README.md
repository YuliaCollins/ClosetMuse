# Closet Muse - AI Personal Stylist

## How to Deploy (Make it Live)

Since this is a modern React application, it requires a "Build Step". You cannot just drag the files to a static host.

### The Easiest Way (Works on iPhone)

1. **GitHub**: Upload these files to a new GitHub Repository.
2. **Vercel**: 
   - Go to Vercel.com and log in with GitHub.
   - Click "Add New Project" and select your repository.
   - **IMPORTANT**: In "Environment Variables", add:
     - Name: `API_KEY`
     - Value: `[Your Google Gemini API Key]`
   - Click **Deploy**.

Vercel will handle all the technical building and hosting for free.

### Manual Build (Advanced)

If you are on a computer with Node.js installed:

```bash
npm install
npm run build
```

Then upload the `dist` folder to Netlify Drop.
